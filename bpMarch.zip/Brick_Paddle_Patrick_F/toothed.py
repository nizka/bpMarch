import random 
class Toothed:
    def __init__(self):
        self.posY = 40
        self.posX =random. randint(20,width-40)
        self.radius1=40       
    def update(self):
        self.posY += 2
        if self.posY==740:
            self.posY=40
            self.posX=random. randint(20,width-40) 
    def draw(self):
        #noStroke()
        fill(235, 64, 52)
        circle(self.posX, self.posY, self.radius1)
        fill(0)
        circle(self.posX+10, self.posY-5, self.radius1-35)
        circle(self.posX-10, self.posY-5, self.radius1-35)
        #triangle(self.posX-30, self.posY-30,self.posX+10, self.posY-30,self.posX-20, self.posY-50)
        stroke(15)
        line(self.posX-6, self.posY+6,self.posX+6, self.posY+6)
        triangle(self.posX-8, self.posY+6,self.posX-2, self.posY+6,self.posX-4, self.posY+10)
        triangle(self.posX+8, self.posY+6,self.posX+2, self.posY+6,self.posX+4, self.posY+10)
        triangle(self.posX-2, self.posY+6,self.posX+2, self.posY+6,self.posX, self.posY+10)
        fill(235, 64, 52)
        textSize(20)
        text("Bite!!!", self.posX+10, self.posY-30)
        #fill(192, 192, 192)
        #circle(self.pos_x - 1, self.pos_y - 1, 2*self.radius) 
