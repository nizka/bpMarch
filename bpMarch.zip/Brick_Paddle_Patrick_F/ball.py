class Ball:
    def __init__(self, pos_x, pos_y):
        self.pos_x = pos_x
        self.pos_y = pos_y
        self.speed_x = 0
        self.speed_y = 0
        self.radius = 20
        
    def hit_test(self, x, y):
        # Returns true if the coordinate x, y is within the ball.
        return (self.pos_x - x) ** 2 + (self.pos_y - y) ** 2 < self.radius ** 2
        
    def update(self):
        self.pos_x += self.speed_x
        self.pos_y += self.speed_y
        
    def draw(self):
        noStroke()
        fill(235, 64, 52)
        circle(self.pos_x, self.pos_y, self.radius)
        fill(240, 171, 168)
        circle(self.pos_x+2, self.pos_y+1, self.radius-15)
        #fill(192, 192, 192)
        #circle(self.pos_x - 1, self.pos_y - 1, 2*self.radius)
